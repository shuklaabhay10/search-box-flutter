import 'package:flutter/material.dart';
import 'api_service.dart';
import 'movie_model.dart';

class MovieProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Movie> _movies = [];
  bool _isLoading = false;

  List<Movie> get movies => _movies;
  bool get isLoading => _isLoading;

  Future<void> searchMovies(String query) async {
    _isLoading = true;
    notifyListeners();

    _movies = await _apiService.fetchMovies(query);
    _isLoading = false;
    notifyListeners();
  }
}
