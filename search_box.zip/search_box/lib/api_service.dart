import 'dart:convert';
import 'package:http/http.dart' as http;
import 'movie_model.dart';

class ApiService {
  final String apiKey =
      "c9fc531793578bb4ea72c40e15cccf8d"; 

  Future<List<Movie>> fetchMovies(String query) async {
    final url = 'https://www.themoviedb.org//?s=$query&apikey=$apiKey';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List results = data['Search'] ?? [];
      return results.map((movie) => Movie.fromJson(movie)).toList();
    } else {
      throw Exception('Failed to load movies');
    }
  }
}
